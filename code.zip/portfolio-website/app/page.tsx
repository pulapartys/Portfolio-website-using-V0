import { HeroSection } from "@/components/hero-section"
import { AboutMe } from "@/components/about-me"
import { ProjectsSection } from "@/components/projects-section"
import { CertificationsSection } from "@/components/certifications-section"
import { ContactSection } from "@/components/contact-section"
import { SiteFooter } from "@/components/site-footer"
import { SiteHeader } from "@/components/site-header"
import { WorkExperience } from "@/components/work-experience"
import { ScrollProgress } from "@/components/scroll-progress"
import { MouseFollower } from "@/components/mouse-follower"
import { ScrollReveal } from "@/components/scroll-reveal"

export default function Home() {
  return (
    <div className="min-h-screen bg-black overflow-hidden">
      <MouseFollower />
      <ScrollProgress />
      <SiteHeader />
      <main className="flex flex-col items-center">
        <ScrollReveal>
          <HeroSection />
        </ScrollReveal>
        <ScrollReveal>
          <AboutMe />
        </ScrollReveal>
        <ScrollReveal>
          <WorkExperience />
        </ScrollReveal>
        <ScrollReveal>
          <ProjectsSection />
        </ScrollReveal>
        <ScrollReveal>
          <CertificationsSection />
        </ScrollReveal>
        <ScrollReveal>
          <ContactSection />
        </ScrollReveal>
      </main>
      <SiteFooter />
    </div>
  )
}
