"use client"

import { useRef } from "react"
import { motion, useInView } from "framer-motion"
import { ProjectCard } from "@/components/project-card"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"

export function ProjectsSection() {
  const ref = useRef<HTMLDivElement>(null)
  const isInView = useInView(ref, { once: false, amount: 0.2 })

  const projects = [
    {
      title: "SpendWise Bot",
      description:
        "An AI-powered budget tracker built with Voiceflow and Flask backend. Helps users manage expenses through natural language conversations.",
      imageSrc: "/images/spendwise.png",
      tags: ["Voiceflow", "Flask", "Python", "AI"],
    },
    {
      title: "Microbial Threat Detection App",
      description:
        "Pega-based project to identify and seize harmful microbes and report them to WHO. Features real-time monitoring and alert systems.",
      imageSrc: "/images/microbial-threat.png",
      tags: ["Pega", "Healthcare", "Data Analysis"],
    },
    {
      title: "HR Management System",
      description:
        "Pega-based project with case life cycle & policy automation. Streamlines HR processes including onboarding, performance reviews, and leave management.",
      imageSrc: "/images/hrms.png",
      tags: ["Pega", "HR Tech", "Automation"],
    },
  ]

  return (
    <section id="projects" className="py-20 relative bg-black" ref={ref}>
      <div className="absolute inset-0 pointer-events-none"></div>

      {/* Background with subtle animation */}
      <div className="absolute inset-0 overflow-hidden">
        <motion.div
          className="absolute inset-0 bg-gradient-to-br from-teal-950/20 via-black to-blue-950/20 opacity-50"
          animate={{
            backgroundPosition: ["0% 0%", "100% 100%"],
          }}
          transition={{
            duration: 20,
            repeat: Number.POSITIVE_INFINITY,
            repeatType: "reverse",
          }}
        />
      </div>

      <div className="container relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <Badge
            variant="outline"
            className="px-4 py-1 text-sm font-medium bg-gray-900/50 backdrop-blur-sm border-teal-400/50 text-teal-400 mb-4"
          >
            My Work
          </Badge>
          <h2 className="text-3xl md:text-4xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-teal-400 via-indigo-400 to-blue-400 glow">
            Featured Projects
          </h2>
          <p className="text-gray-300 max-w-2xl mx-auto">
            Here are some of the projects I've worked on that showcase my skills and experience.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <ProjectCard
              key={project.title}
              title={project.title}
              description={project.description}
              imageSrc={project.imageSrc}
              tags={project.tags}
              index={index}
            />
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="mt-12 text-center"
        >
          <p className="text-gray-400 mb-4">Want to see more of my work?</p>
          <Link
            href="https://www.linkedin.com/in/sreeja-pulaparty-8350b4267/"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block relative"
          >
            <span className="relative z-10 text-lg font-medium text-blue-400 hover:text-blue-300 transition-colors cursor-pointer hover:glow">
              View All Projects →
            </span>
            <motion.div
              className="absolute -bottom-1 left-0 right-0 h-0.5 bg-gradient-to-r from-blue-400 to-teal-400"
              initial={{ width: 0 }}
              whileInView={{ width: "100%" }}
              transition={{ duration: 0.4 }}
            />
          </Link>
        </motion.div>
      </div>
    </section>
  )
}
