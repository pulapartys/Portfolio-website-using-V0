"use client"

import { motion, useInView } from "framer-motion"
import { useRef, useState, useEffect } from "react"
import { Badge } from "@/components/ui/badge"
import { Card } from "@/components/ui/card"
import { Brain, Code, Lightbulb, Users } from "lucide-react"
import Image from "next/image"

export function AboutMe() {
  const ref = useRef<HTMLDivElement>(null)
  const isInView = useInView(ref, { once: false, amount: 0.3 })
  const [typedLines, setTypedLines] = useState<number>(0)
  const [cursorPosition, setCursorPosition] = useState<number>(0)
  const [showCursor, setShowCursor] = useState<boolean>(true)

  // Code lines to be displayed
  const codeLines = [
    { type: "comment", content: "// About Me" },
    { type: "keyword", content: "const developer = {" },
    { type: "property", content: '  name: "Sreeja Pulaparty",' },
    { type: "property", content: '  role: "Master\'s student at Northeastern University",' },
    { type: "property", content: '  specialization: "Software Engineering Systems",' },
    { type: "property", content: "  experience: [" },
    { type: "string", content: '    "Pega",  // Low-code platform expertise' },
    { type: "string", content: '    "GenAI", // Artificial intelligence applications' },
    { type: "string", content: '    "Low-code platforms" // Building scalable solutions' },
    { type: "property", content: "  ]," },
    { type: "property", content: '  strengths: "Building scalable, user-friendly solutions",' },
    { type: "property", content: '  environment: "Fast-paced, cross-functional teams",' },
    { type: "property", content: '  passion: "Intersection of AI and business applications",' },
    { type: "property", content: '  mission: "Leverage technology to solve real-world problems"' },
    { type: "keyword", content: "};" },
  ]

  // Start typing animation when section is in view
  useEffect(() => {
    if (isInView && typedLines === 0) {
      const typingInterval = setInterval(() => {
        setTypedLines((prev) => {
          if (prev < codeLines.length) {
            return prev + 1
          } else {
            clearInterval(typingInterval)
            return prev
          }
        })
      }, 300)

      return () => clearInterval(typingInterval)
    }
  }, [isInView, codeLines.length, typedLines])

  // Blinking cursor effect
  useEffect(() => {
    const cursorInterval = setInterval(() => {
      setShowCursor((prev) => !prev)
    }, 500)

    return () => clearInterval(cursorInterval)
  }, [])

  // Function to highlight keywords in a line
  const highlightKeywords = (line: string) => {
    return line
      .replace(/Pega/g, '<span class="keyword-pega">Pega</span>')
      .replace(/GenAI/g, '<span class="keyword-genai">GenAI</span>')
      .replace(/Low-code platforms/g, '<span class="keyword-lowcode">Low-code platforms</span>')
  }

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.6,
      },
    },
  }

  const skills = [
    { name: "Problem Solving", icon: <Lightbulb className="h-6 w-6 text-yellow-400" /> },
    { name: "AI & ML", icon: <Brain className="h-6 w-6 text-blue-400" /> },
    { name: "Low-Code Development", icon: <Code className="h-6 w-6 text-teal-400" /> },
    { name: "Team Collaboration", icon: <Users className="h-6 w-6 text-indigo-400" /> },
  ]

  return (
    <section id="about" className="py-20 relative overflow-hidden bg-black" ref={ref}>
      <div className="absolute inset-0 bg-black/50 pointer-events-none"></div>

      {/* Background with subtle animation */}
      <div className="absolute inset-0 overflow-hidden">
        <motion.div
          className="absolute inset-0 bg-gradient-to-br from-blue-950/20 via-black to-teal-950/20 opacity-50"
          animate={{
            backgroundPosition: ["0% 0%", "100% 100%"],
          }}
          transition={{
            duration: 20,
            repeat: Number.POSITIVE_INFINITY,
            repeatType: "reverse",
          }}
        />
      </div>

      <div className="container relative z-10">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
          className="max-w-4xl mx-auto text-center"
        >
          <motion.div variants={itemVariants} className="mb-8">
            <Badge
              variant="outline"
              className="px-4 py-1 text-sm font-medium bg-gray-900/50 backdrop-blur-sm border-blue-400/50 text-blue-400 mb-4"
            >
              About Me
            </Badge>
            <h2 className="text-3xl md:text-4xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-400 via-indigo-400 to-teal-400 glow">
              Who I Am
            </h2>
          </motion.div>

          <motion.div variants={itemVariants} className="flex flex-col md:flex-row items-center gap-8 mb-8">
            <div className="w-32 h-32 rounded-full overflow-hidden border-4 border-blue-400/30 flex-shrink-0 relative group">
              <Image
                src="/images/profile.jpeg"
                alt="Sreeja Pulaparty"
                width={128}
                height={128}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
              />
              <motion.div
                className="absolute inset-0 bg-gradient-to-r from-blue-500/20 to-teal-500/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                whileHover={{ opacity: 0.3 }}
              />
            </div>

            <div className="code-editor-container w-full flex-1">
              <div className="code-editor">
                <div className="code-editor-header">
                  <div className="code-editor-dots">
                    <span className="code-editor-dot code-editor-dot-red"></span>
                    <span className="code-editor-dot code-editor-dot-yellow"></span>
                    <span className="code-editor-dot code-editor-dot-green"></span>
                  </div>
                  <div className="code-editor-title">about-me.tsx</div>
                </div>
                <div className="code-editor-body">
                  {codeLines.map((line, index) => (
                    <div key={index} className={`code-line ${index < typedLines ? "" : "hidden"}`}>
                      <span className="code-line-number">{index + 1}</span>
                      <span className={`code-line-content code-${line.type}`}>
                        {index === 6 || index === 7 || index === 8 ? (
                          <span dangerouslySetInnerHTML={{ __html: highlightKeywords(line.content) }} />
                        ) : (
                          line.content
                        )}
                        {index === typedLines - 1 && showCursor && <span className="code-cursor">|</span>}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>

          <motion.div variants={itemVariants} className="mt-12">
            <h3 className="text-xl font-semibold mb-6 text-gray-200">Core Competencies</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {skills.map((skill, index) => (
                <motion.div
                  key={skill.name}
                  whileHover={{ y: -5, scale: 1.05, boxShadow: "0 0 15px rgba(59, 130, 246, 0.3)" }}
                  transition={{ type: "spring", stiffness: 300, damping: 10 }}
                >
                  <Card className="h-full p-4 flex flex-col items-center justify-center gap-3 bg-gray-900/50 backdrop-blur-sm border border-gray-800 hover:border-blue-400/50 transition-all duration-300">
                    {skill.icon}
                    <span className="text-sm font-medium text-gray-200">{skill.name}</span>
                  </Card>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  )
}
