"use client"

import Link from "next/link"
import { Linkedin, Mail, Github, Heart } from "lucide-react"
import { motion } from "framer-motion"

export function SiteFooter() {
  return (
    <footer className="py-8 relative overflow-hidden bg-black border-t border-gray-800">
      <div className="absolute inset-0 bg-black pointer-events-none"></div>

      <div className="container relative z-10">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <motion.div
            className="mb-4 md:mb-0"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
          >
            <Link
              href="/"
              className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-400 via-indigo-400 to-teal-400 hover:glow transition-all duration-300"
            >
              SP
            </Link>
            <p className="text-sm text-gray-400 mt-1">
              &copy; {new Date().getFullYear()} Sreeja Pulaparty. All rights reserved.
            </p>
          </motion.div>

          <motion.div
            className="flex space-x-4"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            viewport={{ once: true }}
          >
            <motion.div whileHover={{ y: -5, scale: 1.1 }} whileTap={{ scale: 0.9 }}>
              <Link
                href="https://www.linkedin.com/in/sreeja-pulaparty-8350b4267/"
                target="_blank"
                rel="noopener noreferrer"
                className="text-gray-400 hover:text-blue-400 transition-colors"
              >
                <Linkedin className="h-5 w-5" />
                <span className="sr-only">LinkedIn</span>
              </Link>
            </motion.div>
            <motion.div whileHover={{ y: -5, scale: 1.1 }} whileTap={{ scale: 0.9 }}>
              <Link
                href="mailto:pulaparty.s@northeastern.edu"
                className="text-gray-400 hover:text-indigo-400 transition-colors"
              >
                <Mail className="h-5 w-5" />
                <span className="sr-only">Email</span>
              </Link>
            </motion.div>
            <motion.div whileHover={{ y: -5, scale: 1.1 }} whileTap={{ scale: 0.9 }}>
              <Link
                href="https://github.com/pulapartys?tab=repositories"
                target="_blank"
                rel="noopener noreferrer"
                className="text-gray-400 hover:text-teal-400 transition-colors"
              >
                <Github className="h-5 w-5" />
                <span className="sr-only">GitHub</span>
              </Link>
            </motion.div>
          </motion.div>
        </div>

        <motion.div
          className="mt-8 pt-6 border-t border-gray-800 text-center text-sm text-gray-400"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.4 }}
          viewport={{ once: true }}
        >
          <p className="flex items-center justify-center gap-2">
            Made with <Heart className="h-4 w-4 text-indigo-400 animate-pulse" /> and modern web technologies
          </p>
        </motion.div>
      </div>
    </footer>
  )
}
