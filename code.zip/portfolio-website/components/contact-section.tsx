"use client"

import { useRef } from "react"
import { motion, useInView } from "framer-motion"
import { Card, CardContent } from "@/components/ui/card"
import { Linkedin, Mail, Github } from "lucide-react"
import { ContactForm } from "@/components/contact-form"
import { Badge } from "@/components/ui/badge"

export function ContactSection() {
  const ref = useRef<HTMLDivElement>(null)
  const isInView = useInView(ref, { once: false, amount: 0.2 })

  return (
    <section id="contact" className="py-20 relative bg-black" ref={ref}>
      <div className="absolute inset-0 pointer-events-none"></div>

      {/* Background with subtle animation */}
      <div className="absolute inset-0 overflow-hidden">
        <motion.div
          className="absolute inset-0 bg-gradient-to-br from-blue-950/20 via-black to-teal-950/20 opacity-50"
          animate={{
            backgroundPosition: ["0% 0%", "100% 100%"],
          }}
          transition={{
            duration: 20,
            repeat: Number.POSITIVE_INFINITY,
            repeatType: "reverse",
          }}
        />
      </div>

      <div className="container relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <Badge
            variant="outline"
            className="px-4 py-1 text-sm font-medium bg-gray-900/50 backdrop-blur-sm border-teal-400/50 text-teal-400 mb-4"
          >
            Get In Touch
          </Badge>
          <h2 className="text-3xl md:text-4xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-teal-400 via-indigo-400 to-blue-400 glow">
            Let's Connect
          </h2>
          <p className="text-gray-300 max-w-2xl mx-auto">
            Have a project in mind or want to collaborate? Feel free to reach out!
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: -20 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            whileHover={{ scale: 1.02 }}
          >
            <Card className="h-full bg-gray-900/50 backdrop-blur-sm border border-gray-800 hover:border-teal-400/30 transition-all duration-300 overflow-hidden relative group">
              <CardContent className="p-6 relative z-10">
                <h3 className="text-xl font-semibold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-teal-400 to-blue-400 glow-sm">
                  Contact Information
                </h3>
                <div className="space-y-4">
                  <motion.div
                    className="flex items-center gap-3"
                    whileHover={{ x: 5 }}
                    transition={{ type: "spring", stiffness: 300, damping: 10 }}
                  >
                    <div className="p-2 rounded-full bg-teal-400/10">
                      <Mail className="h-5 w-5 text-teal-400" />
                    </div>
                    <a
                      href="mailto:pulaparty.s@northeastern.edu"
                      className="text-gray-300 hover:text-teal-400 transition-colors"
                    >
                      pulaparty.s@northeastern.edu
                    </a>
                  </motion.div>
                  <motion.div
                    className="flex items-center gap-3"
                    whileHover={{ x: 5 }}
                    transition={{ type: "spring", stiffness: 300, damping: 10 }}
                  >
                    <div className="p-2 rounded-full bg-blue-400/10">
                      <Linkedin className="h-5 w-5 text-blue-400" />
                    </div>
                    <a
                      href="https://www.linkedin.com/in/sreeja-pulaparty-8350b4267/"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-gray-300 hover:text-blue-400 transition-colors"
                    >
                      linkedin.com/in/sreeja-pulaparty-8350b4267
                    </a>
                  </motion.div>
                  <motion.div
                    className="flex items-center gap-3"
                    whileHover={{ x: 5 }}
                    transition={{ type: "spring", stiffness: 300, damping: 10 }}
                  >
                    <div className="p-2 rounded-full bg-indigo-400/10">
                      <Github className="h-5 w-5 text-indigo-400" />
                    </div>
                    <a
                      href="https://github.com/pulapartys?tab=repositories"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-gray-300 hover:text-indigo-400 transition-colors"
                    >
                      github.com/pulapartys
                    </a>
                  </motion.div>
                </div>

                <div className="mt-8 p-4 rounded-lg bg-gray-800/50 backdrop-blur-sm">
                  <h4 className="text-lg font-medium mb-3 text-gray-200">Current Status</h4>
                  <p className="text-gray-400">
                    I'm currently open to full-time software engineering and business analyst roles starting Summer
                    2025.
                  </p>
                </div>
              </CardContent>

              <motion.div
                className="absolute -inset-px rounded-xl opacity-0 group-hover:opacity-100 bg-gradient-to-r from-teal-400/10 via-blue-400/10 to-indigo-400/10 blur-sm -z-10"
                animate={{
                  opacity: [0, 0.5, 0],
                }}
                transition={{
                  duration: 3,
                  repeat: Number.POSITIVE_INFINITY,
                  repeatType: "reverse",
                }}
              />
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: 20 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            whileHover={{ scale: 1.02 }}
          >
            <ContactForm />
          </motion.div>
        </div>
      </div>
    </section>
  )
}
