"use client"

import type React from "react"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Send, CheckCircle } from "lucide-react"
import { motion } from "framer-motion"

export function ContactForm() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: "",
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [submitted, setSubmitted] = useState(false)
  const [focused, setFocused] = useState<string | null>(null)

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleFocus = (name: string) => {
    setFocused(name)
  }

  const handleBlur = () => {
    setFocused(null)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulate form submission
    await new Promise((resolve) => setTimeout(resolve, 1500))

    setIsSubmitting(false)
    setSubmitted(true)
    setFormData({ name: "", email: "", message: "" })

    // Reset success message after 5 seconds
    setTimeout(() => {
      setSubmitted(false)
    }, 5000)
  }

  return (
    <Card className="h-full bg-gray-900/50 backdrop-blur-sm border border-gray-800 hover:border-blue-400/30 transition-all duration-300 overflow-hidden relative group">
      <CardContent className="p-6 relative z-10">
        {submitted ? (
          <motion.div
            className="h-full flex flex-col items-center justify-center text-center py-8"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ type: "spring", stiffness: 300, damping: 20 }}
          >
            <motion.div
              className="rounded-full bg-green-500/10 p-3 mb-4"
              animate={{
                scale: [1, 1.2, 1],
                rotate: [0, 10, -10, 0],
              }}
              transition={{ duration: 0.5 }}
            >
              <CheckCircle className="h-8 w-8 text-green-500" />
            </motion.div>
            <h3 className="text-xl font-semibold mb-2 bg-clip-text text-transparent bg-gradient-to-r from-green-500 to-teal-400 glow-sm">
              Message Sent!
            </h3>
            <p className="text-gray-300">Thank you for reaching out. I'll get back to you as soon as possible.</p>
          </motion.div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name" className="text-sm font-medium text-gray-300">
                Name
              </Label>
              <div className="relative">
                <Input
                  id="name"
                  name="name"
                  placeholder="Your name"
                  value={formData.name}
                  onChange={handleChange}
                  onFocus={() => handleFocus("name")}
                  onBlur={handleBlur}
                  required
                  className="transition-all duration-200 focus:ring-2 focus:ring-blue-400/50 bg-gray-800/50 backdrop-blur-sm border-gray-700 text-white"
                />
                <motion.div
                  className="absolute -inset-px rounded-md opacity-0 bg-gradient-to-r from-blue-400/20 to-teal-400/20 -z-10"
                  animate={{
                    opacity: focused === "name" ? 0.5 : 0,
                  }}
                  transition={{ duration: 0.3 }}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="email" className="text-sm font-medium text-gray-300">
                Email
              </Label>
              <div className="relative">
                <Input
                  id="email"
                  name="email"
                  type="email"
                  placeholder="Your email address"
                  value={formData.email}
                  onChange={handleChange}
                  onFocus={() => handleFocus("email")}
                  onBlur={handleBlur}
                  required
                  className="transition-all duration-200 focus:ring-2 focus:ring-blue-400/50 bg-gray-800/50 backdrop-blur-sm border-gray-700 text-white"
                />
                <motion.div
                  className="absolute -inset-px rounded-md opacity-0 bg-gradient-to-r from-teal-400/20 to-blue-400/20 -z-10"
                  animate={{
                    opacity: focused === "email" ? 0.5 : 0,
                  }}
                  transition={{ duration: 0.3 }}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="message" className="text-sm font-medium text-gray-300">
                Message
              </Label>
              <div className="relative">
                <Textarea
                  id="message"
                  name="message"
                  placeholder="Your message"
                  value={formData.message}
                  onChange={handleChange}
                  onFocus={() => handleFocus("message")}
                  onBlur={handleBlur}
                  required
                  className="min-h-[120px] transition-all duration-200 focus:ring-2 focus:ring-blue-400/50 bg-gray-800/50 backdrop-blur-sm border-gray-700 text-white resize-none"
                />
                <motion.div
                  className="absolute -inset-px rounded-md opacity-0 bg-gradient-to-r from-indigo-400/20 to-teal-400/20 -z-10"
                  animate={{
                    opacity: focused === "message" ? 0.5 : 0,
                  }}
                  transition={{ duration: 0.3 }}
                />
              </div>
            </div>

            <motion.div whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.97 }}>
              <Button
                type="submit"
                className="w-full bg-gradient-to-r from-blue-500 to-teal-500 hover:from-blue-600 hover:to-teal-600 transition-all duration-300 shadow-lg hover:shadow-blue-500/20 text-white"
                disabled={isSubmitting}
              >
                {isSubmitting ? (
                  <span className="flex items-center gap-2">
                    <svg
                      className="animate-spin -ml-1 mr-2 h-4 w-4 text-white"
                      xmlns="http://www.w3.org/2000/svg"
                      fill="none"
                      viewBox="0 0 24 24"
                    >
                      <circle
                        className="opacity-25"
                        cx="12"
                        cy="12"
                        r="10"
                        stroke="currentColor"
                        strokeWidth="4"
                      ></circle>
                      <path
                        className="opacity-75"
                        fill="currentColor"
                        d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                      ></path>
                    </svg>
                    Sending...
                  </span>
                ) : (
                  <span className="flex items-center gap-2">
                    Send Message
                    <Send className="h-4 w-4" />
                  </span>
                )}
              </Button>
            </motion.div>
          </form>
        )}
      </CardContent>

      <motion.div
        className="absolute -inset-px rounded-xl opacity-0 group-hover:opacity-100 bg-gradient-to-r from-blue-400/10 via-indigo-400/10 to-teal-400/10 blur-sm -z-10"
        animate={{
          opacity: [0, 0.5, 0],
        }}
        transition={{
          duration: 3,
          repeat: Number.POSITIVE_INFINITY,
          repeatType: "reverse",
        }}
      />
    </Card>
  )
}
