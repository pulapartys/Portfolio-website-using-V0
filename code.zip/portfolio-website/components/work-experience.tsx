"use client"

import { useRef } from "react"
import { motion, useInView } from "framer-motion"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Calendar, Building, Briefcase } from "lucide-react"

export function WorkExperience() {
  const ref = useRef<HTMLDivElement>(null)
  const isInView = useInView(ref, { once: false, amount: 0.2 })

  const experiences = [
    {
      title: "Business Analyst & System Architect Intern",
      company: "Bluevoir Technologies",
      location: "India",
      project: "Microbial Threat Detection",
      date: "Aug 2023 – Jul 2024",
      highlights: [
        "Accelerated requirements gathering with Pega GenAI Blueprint",
        "Designed secure portals with RBAC for different user roles",
        "Integrated GenAI Connect shapes and Knowledge Buddy Widget",
      ],
      tools: ["Pega", "GenAI", "Blueprint", "RBAC", "UX Design"],
      color: "from-blue-400 to-indigo-400",
    },
    {
      title: "Business Analyst Intern",
      company: "Bluevoir Technologies",
      location: "India",
      project: "Human Resources Management System",
      date: "Jan 2023 – May 2023",
      highlights: [
        "Documented case life cycles using App Studio",
        "Created decision tables for HR policy automation",
        "Developed UI/UX specs and mockups for development team",
      ],
      tools: ["App Studio", "GenAI", "Blueprint", "UX", "Decision Tables"],
      color: "from-teal-400 to-blue-400",
    },
  ]

  return (
    <section id="experience" className="py-20 relative bg-black" ref={ref}>
      <div className="container relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <Badge
            variant="outline"
            className="px-4 py-1 text-sm font-medium bg-gray-900/50 backdrop-blur-sm border-indigo-400/50 text-indigo-400 mb-4"
          >
            Career Path
          </Badge>
          <h2 className="text-3xl md:text-4xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-blue-400 via-indigo-400 to-teal-400 glow">
            Work Experience
          </h2>
          <p className="text-gray-300 max-w-2xl mx-auto">
            My professional journey and contributions in the tech industry.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
          {experiences.map((exp, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
              transition={{ duration: 0.5, delay: index * 0.2 }}
              whileHover={{ y: -5, transition: { duration: 0.2 } }}
            >
              <Card className="h-full overflow-hidden shadow-lg hover:shadow-blue-500/10 transition-all duration-300 border border-gray-800 bg-gray-900/50 backdrop-blur-sm">
                <div className={`h-2 bg-gradient-to-r ${exp.color}`}></div>
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-start gap-2 mb-1">
                    <CardTitle className="text-xl font-bold text-white">{exp.title}</CardTitle>
                  </div>
                  <div className="flex items-center text-sm text-gray-400 mb-1">
                    <Building className="h-4 w-4 mr-1 text-blue-400" />
                    <span className="font-medium">{exp.company}</span>
                    <span className="mx-2">•</span>
                    <span>{exp.location}</span>
                  </div>
                  <div className="flex items-center text-sm text-gray-400">
                    <Briefcase className="h-4 w-4 mr-1 text-teal-400" />
                    <span className="font-medium">{exp.project}</span>
                  </div>
                  <div className="flex items-center text-xs text-gray-400 mt-1">
                    <Calendar className="h-3 w-3 mr-1 text-indigo-400" />
                    {exp.date}
                  </div>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2 mb-4 pl-1">
                    {exp.highlights.map((item, i) => (
                      <motion.li
                        key={i}
                        initial={{ opacity: 0, x: -5 }}
                        animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: -5 }}
                        transition={{ duration: 0.3, delay: index * 0.1 + i * 0.1 }}
                        className="flex items-start text-sm text-gray-300"
                      >
                        <span className="text-blue-400 mr-2">•</span>
                        <span>{item}</span>
                      </motion.li>
                    ))}
                  </ul>
                  <div className="flex flex-wrap gap-1.5 mt-3">
                    {exp.tools.map((tool, i) => (
                      <Badge
                        key={i}
                        variant="secondary"
                        className="text-xs bg-gray-800 text-gray-300 hover:bg-gray-700"
                      >
                        {tool}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
