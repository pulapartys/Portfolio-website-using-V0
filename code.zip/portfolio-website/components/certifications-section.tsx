"use client"

import { useRef } from "react"
import { motion, useInView } from "framer-motion"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Award, CheckCircle, FileCheck, Briefcase, Code } from "lucide-react"

export function CertificationsSection() {
  const ref = useRef<HTMLDivElement>(null)
  const isInView = useInView(ref, { once: false, amount: 0.2 })

  const certifications = [
    {
      title: "Pega: Certified System Architect (87V1)",
      icon: <Code className="h-10 w-10 text-blue-400" />,
      issuer: "Pegasystems",
      color: "from-blue-400 to-indigo-400",
    },
    {
      title: "Pega: Certified Business Architect (87V1)",
      icon: <Briefcase className="h-10 w-10 text-indigo-400" />,
      issuer: "Pegasystems",
      color: "from-indigo-400 to-blue-400",
    },
    {
      title: "Salesforce: Certified Administrator",
      icon: <CheckCircle className="h-10 w-10 text-teal-400" />,
      issuer: "Salesforce",
      color: "from-teal-400 to-blue-400",
    },
    {
      title: "Salesforce: Certified Associate",
      icon: <FileCheck className="h-10 w-10 text-blue-400" />,
      issuer: "Salesforce",
      color: "from-blue-400 to-teal-400",
    },
    {
      title: "Microsoft: Intro to Programming Using Python",
      icon: <Award className="h-10 w-10 text-yellow-400" />,
      issuer: "Microsoft",
      color: "from-yellow-400 to-teal-400",
    },
  ]

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20, scale: 0.95 },
    visible: {
      opacity: 1,
      y: 0,
      scale: 1,
      transition: {
        type: "spring",
        stiffness: 100,
        damping: 10,
      },
    },
  }

  return (
    <section id="certifications" className="py-20 relative bg-black" ref={ref}>
      <div className="absolute inset-0 pointer-events-none"></div>

      {/* Background with subtle animation */}
      <div className="absolute inset-0 overflow-hidden">
        <motion.div
          className="absolute inset-0 bg-gradient-to-br from-indigo-950/20 via-black to-blue-950/20 opacity-50"
          animate={{
            backgroundPosition: ["0% 0%", "100% 100%"],
          }}
          transition={{
            duration: 20,
            repeat: Number.POSITIVE_INFINITY,
            repeatType: "reverse",
          }}
        />
      </div>

      <div className="container relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <Badge
            variant="outline"
            className="px-4 py-1 text-sm font-medium bg-gray-900/50 backdrop-blur-sm border-indigo-400/50 text-indigo-400 mb-4"
          >
            Credentials
          </Badge>
          <h2 className="text-3xl md:text-4xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-indigo-400 via-blue-400 to-teal-400 glow">
            Professional Certifications
          </h2>
          <p className="text-gray-300 max-w-2xl mx-auto">
            Professional certifications that validate my expertise and knowledge.
          </p>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {certifications.map((cert, index) => (
            <motion.div
              key={cert.title}
              variants={itemVariants}
              whileHover={{
                y: -10,
                transition: { type: "spring", stiffness: 300, damping: 10 },
              }}
            >
              <Card className="h-full relative group overflow-hidden bg-gray-900/50 backdrop-blur-sm border border-gray-800 hover:border-indigo-400/30 transition-all duration-300">
                <CardHeader className="flex flex-row items-center gap-4 relative z-10">
                  <div className="p-2 rounded-full bg-gray-800/50 backdrop-blur-sm">{cert.icon}</div>
                  <CardTitle className="text-lg text-white">{cert.title}</CardTitle>
                </CardHeader>
                <CardContent className="relative z-10">
                  <Badge
                    variant="outline"
                    className={`bg-gradient-to-r ${cert.color} bg-clip-text text-transparent border-none glow-sm`}
                  >
                    {cert.issuer}
                  </Badge>
                </CardContent>

                <motion.div
                  className="absolute -inset-px rounded-xl opacity-0 group-hover:opacity-100 bg-gradient-to-r from-blue-400/10 via-indigo-400/10 to-teal-400/10 blur-sm -z-10"
                  animate={{
                    opacity: [0, 0.5, 0],
                  }}
                  transition={{
                    duration: 3,
                    repeat: Number.POSITIVE_INFINITY,
                    repeatType: "reverse",
                  }}
                />
              </Card>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  )
}
