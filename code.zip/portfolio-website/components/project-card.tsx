"use client"

import { motion } from "framer-motion"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import Image from "next/image"
import { useState } from "react"

interface ProjectCardProps {
  title: string
  description: string
  imageSrc: string
  tags: string[]
  index: number
}

export function ProjectCard({ title, description, imageSrc, tags, index }: ProjectCardProps) {
  const [isHovered, setIsHovered] = useState(false)

  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      whileHover={{ y: -10 }}
      className="h-full perspective-1000"
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
    >
      <Card className="overflow-hidden h-full flex flex-col relative group transform-gpu transition-all duration-500 border-gray-800 hover:border-blue-400/30 bg-gray-900/50 backdrop-blur-sm">
        <div className="relative h-48 overflow-hidden">
          <Image
            src={imageSrc || "/placeholder.svg"}
            alt={title}
            fill
            className="object-cover transition-transform duration-500 group-hover:scale-110"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent opacity-70 group-hover:opacity-90 transition-opacity duration-300"></div>

          <motion.div
            className="absolute inset-0 bg-gradient-to-r from-blue-500/20 to-teal-500/20 opacity-0 mix-blend-overlay"
            animate={{
              opacity: isHovered ? 0.5 : 0,
            }}
            transition={{ duration: 0.3 }}
          />
        </div>

        <CardHeader>
          <CardTitle className="text-xl bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-teal-400 glow-sm">
            {title}
          </CardTitle>
        </CardHeader>

        <CardContent className="flex-grow">
          <CardDescription className="text-base text-gray-300">{description}</CardDescription>
        </CardContent>

        <CardFooter className="flex flex-wrap gap-2">
          {tags.map((tag) => (
            <Badge key={tag} variant="outline" className="text-xs border-blue-400/30 bg-blue-400/5 text-blue-300">
              {tag}
            </Badge>
          ))}
        </CardFooter>

        <motion.div
          className="absolute -inset-px rounded-xl opacity-0 group-hover:opacity-100 bg-gradient-to-r from-blue-400/20 via-indigo-400/20 to-teal-400/20 blur-sm -z-10"
          animate={{
            opacity: isHovered ? [0, 1, 0.5] : 0,
          }}
          transition={{
            duration: 2,
            repeat: isHovered ? Number.POSITIVE_INFINITY : 0,
            repeatType: "reverse",
          }}
        />
      </Card>
    </motion.div>
  )
}
